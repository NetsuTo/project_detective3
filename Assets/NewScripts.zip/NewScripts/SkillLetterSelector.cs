﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SkillLetterSelector : MonoBehaviour
{
    public Transform uiAnchor;       // จุดบนหัว Player
    public GameObject letterPrefab;  // Prefab ของ Text UI
    public Canvas mainCanvas;        // Canvas หลัก
    public float cycleSpeed = 2f;    // ความเร็วหมุนตัวอักษร

    private List<char> letters = new List<char>();
    private List<char> remaining = new List<char>();
    private List<char> originalLetters = new List<char>();  // เก็บ skillID เดิม

    private int currentIndex = 0;
    private float timer = 0f;
    private bool isActive = false;

    private List<GameObject> letterUIs = new List<GameObject>();
    private List<Text> letterTexts = new List<Text>();

    private PlayerSkillManager manager;

    void Start()
    {
        manager = GetComponent<PlayerSkillManager>();
    }

    void Update()
    {
        if (!isActive) return;

        // หมุนตัวอักษร
        timer += Time.deltaTime;
        if (timer >= 1f / cycleSpeed && remaining.Count > 0)
        {
            timer = 0f;
            currentIndex = (currentIndex + 1) % remaining.Count;

            // อัปเดต UI ให้แสดงตัวอักษรปัจจุบัน
            for (int i = 0; i < letterTexts.Count; i++)
            {
                letterTexts[i].text = remaining[currentIndex].ToString();
            }
        }

        // เลือกตัวอักษร (กด O)
        if (Input.GetKeyDown(KeyCode.O) && remaining.Count > 0)
        {
            char chosen = remaining[currentIndex];
            Debug.Log("Chose letter: " + chosen);

            letters.Remove(chosen);
            remaining.RemoveAt(currentIndex);

            // เรียก QTEManager ทันที
            QTEManager qte = FindObjectOfType<QTEManager>();
            if (qte != null)
            {
                if (System.Enum.TryParse(chosen.ToString().ToUpper(), out KeyCode code))
                {
                    List<KeyCode> seq = new List<KeyCode> { code };
                    qte.StartQTE(seq);
                }
            }

            if (remaining.Count == 0)
            {
                Debug.Log("All letters chosen!");
                EndSelection();
            }
            else
            {
                currentIndex = 0;
            }
        }


        // อัปเดตตำแหน่ง UI ให้อยู่เหนือหัว player
        for (int i = 0; i < letterUIs.Count; i++)
        {
            Vector3 offset = new Vector3(i * 50f, 0f, 0f);
            Vector3 screenPos = Camera.main.WorldToScreenPoint(uiAnchor.position) + offset;
            letterUIs[i].transform.position = screenPos;
        }
    }

    public void StartSelection(string skillID)
    {
        if (letterPrefab == null || uiAnchor == null || mainCanvas == null)
        {
            Debug.LogError("กรุณากรอก LetterPrefab, UIAnchor และ MainCanvas ใน Inspector");
            return;
        }

        letters = new List<char>(skillID.ToCharArray());
        remaining = new List<char>(letters);
        originalLetters = new List<char>(letters);  // เก็บ skillID เดิมไว้

        // ล้าง UI เก่า
        foreach (var ui in letterUIs) Destroy(ui);
        letterUIs.Clear();
        letterTexts.Clear();

        // สร้าง Letter UI
        for (int i = 0; i < letters.Count; i++)
        {
            GameObject go = Instantiate(letterPrefab, mainCanvas.transform);
            go.transform.localScale = Vector3.one;

            Text textComp = go.GetComponentInChildren<Text>();
            if (textComp != null)
            {
                textComp.text = letters[i].ToString();
                letterUIs.Add(go);
                letterTexts.Add(textComp);
            }
            else
            {
                Debug.LogError("LetterPrefab ไม่มี Text component");
            }
        }

        currentIndex = 0;
        isActive = true;
    }

    private void EndSelection()
    {
        isActive = false;

        // ลบ Letter UI
        foreach (var go in letterUIs) Destroy(go);
        letterUIs.Clear();
        letterTexts.Clear();

        // ส่ง sequence ไป QTEManager
        QTEManager qte = FindObjectOfType<QTEManager>();
        if (qte != null)
        {
            Debug.Log("Calling StartQTE from SkillLetterSelector");

            List<KeyCode> keySequence = new List<KeyCode>();
            foreach (char c in originalLetters)   // ใช้ skillID เดิม
            {
                if (System.Enum.TryParse(c.ToString().ToUpper(), out KeyCode code))
                {
                    keySequence.Add(code);
                }
                else
                {
                    Debug.LogWarning("ไม่สามารถแปลงตัวอักษร '" + c + "' เป็น KeyCode");
                }
            }

            Debug.Log("Final QTE sequence count = " + keySequence.Count);
            qte.StartQTE(keySequence);
        }
        else
        {
            Debug.LogWarning("QTEManager not found!");
        }
    }
}
