﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class InventorySystem : MonoBehaviour
{
    public static InventorySystem instance;

    [Header("Storage")]
    public List<ItemData> items = new List<ItemData>();
    public int maxSlots = 20;              // 1 ช่อง = 1 ชิ้น (ไม่ stack)

    [Header("Selection & Use")]
    public ItemData selectedItem;          // ไอเท็มที่ถูกเลือกอยู่ตอนนี้
    public bool canUseItems = false;       // PlayerController จะเป็นคนเปิด/ปิดเมื่อเข้า/ออก UseZone

    private void Awake()
    {
        // ✅ Singleton + คงอยู่ข้ามซีน
        if (instance != null && instance != this)
        {
            Destroy(gameObject);
            return;
        }
        instance = this;
        DontDestroyOnLoad(gameObject);

        // รีเฟรช UI ทุกครั้งที่โหลดซีนใหม่
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    private void OnDestroy()
    {
        if (instance == this)
            SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    private void OnSceneLoaded(Scene s, LoadSceneMode m)
    {
        // ซีนใหม่มักมี InventoryUI instance ใหม่ → รีเฟรชรายการให้ของ “ตามมา”
        if (InventoryUI.instance != null)
            InventoryUI.instance.Refresh();
        // ไม่แตะ canUseItems ที่นี่ เพื่อไม่ชนกรณี spawn อยู่ในโซน
    }

    /// เพิ่มไอเท็มเข้าอินเวนทอรี (1 ช่อง = 1 ชิ้น)
    public bool AddItem(ItemData item)
    {
        if (item == null)
        {
            Debug.LogWarning("[InventorySystem] AddItem: item เป็น null");
            return false;
        }
        if (items.Count >= maxSlots)
        {
            Debug.Log("Inventory เต็ม");
            return false;
        }

        items.Add(item);
        Debug.Log($"[InventorySystem] เก็บของ: {item.itemName} | คงเหลือ: {items.Count}");

        if (InventoryUI.instance != null)
            InventoryUI.instance.Refresh();

        return true;
    }

    /// เลือกไอเท็ม (อนุญาตเฉพาะตอนอยู่ใน UseZone)
    public void SelectItem(ItemData item)
    {
        if (!canUseItems)
        {
            Debug.Log("อยู่นอก UseZone: ไม่อนุญาตให้เลือก/ใช้ไอเท็ม");
            return;
        }
        if (item == null)
        {
            Debug.LogWarning("[InventorySystem] SelectItem: item เป็น null");
            return;
        }
        if (!items.Contains(item))
        {
            Debug.LogWarning("[InventorySystem] SelectItem: item ไม่ได้อยู่ในอินเวนทอรี");
            return;
        }

        selectedItem = item;
        // ไม่ Refresh UI ที่นี่ เพื่อรักษาไฮไลต์จากช่องที่คลิก
    }

    /// ลบ 1 ชิ้นเมื่อใช้สำเร็จ
    public bool ConsumeOne(ItemData item)
    {
        if (item == null)
        {
            Debug.LogWarning("[InventorySystem] ConsumeOne: item เป็น null");
            return false;
        }

        int idx = items.IndexOf(item);
        if (idx >= 0)
        {
            items.RemoveAt(idx);
            if (selectedItem == item)
                selectedItem = null;

            if (InventoryUI.instance != null)
                InventoryUI.instance.Refresh();

            Debug.Log($"[InventorySystem] ใช้/ลบไอเท็ม: {item.itemName} | คงเหลือ: {items.Count}");
            return true;
        }

        Debug.LogWarning("[InventorySystem] ConsumeOne: ไม่พบ item ในอินเวนทอรี");
        return false;
    }

    public bool HasItem(ItemData item) => item != null && items.Contains(item);

    public bool RemoveItem(ItemData item)
    {
        if (item == null) return false;

        bool removed = items.Remove(item);
        if (removed)
        {
            if (selectedItem == item)
                selectedItem = null;

            if (InventoryUI.instance != null)
                InventoryUI.instance.Refresh();

            Debug.Log($"[InventorySystem] RemoveItem: {item.itemName}");
        }
        return removed;
    }

    public void ClearSelected() => selectedItem = null;
}
