﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class SpawnManager : MonoBehaviour
{
    public static SpawnManager instance;

    // ค่าที่ทรานซิชันตั้งไว้ก่อนโหลดซีนถัดไป
    public static string nextSpawnId = null;

    [Tooltip("ค้นหา Player โดย Tag = 'Player' ถ้า reference ว่าง")]
    public string playerTag = "Player";

    private void Awake()
    {
        if (instance != null && instance != this) { Destroy(gameObject); return; }
        instance = this;
        DontDestroyOnLoad(gameObject);

        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    private void OnDestroy()
    {
        if (instance == this)
            SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        // หา Player
        GameObject player = GameObject.FindGameObjectWithTag(playerTag);
        if (player == null)
        {
            Debug.LogWarning("[SpawnManager] ไม่พบ Player ในซีน (Tag 'Player')");
            return;
        }

        // หา SpawnPoint ให้ตรง ID
        SpawnPoint target = null;
        if (!string.IsNullOrEmpty(nextSpawnId))
        {
            foreach (var sp in FindObjectsOfType<SpawnPoint>())
            {
                if (sp.spawnId == nextSpawnId) { target = sp; break; }
            }
        }

        // ถ้าไม่เจอ ID เป้าหมาย → ใช้ตัวที่เป็น fallback หรืออันแรกที่เจอ
        if (target == null)
        {
            SpawnPoint fallback = null;
            var all = FindObjectsOfType<SpawnPoint>();
            foreach (var sp in all) if (sp.isFallback) { fallback = sp; break; }
            target = fallback != null ? fallback : (all.Length > 0 ? all[0] : null);
        }

        if (target == null)
        {
            Debug.LogWarning($"[SpawnManager] ไม่พบ SpawnPoint ในซีน '{scene.name}'");
            nextSpawnId = null; // เคลียร์ไว้รอบหน้า
            return;
        }

        // ย้ายตำแหน่ง/ทิศของผู้เล่น
        var cc = player.GetComponent<CharacterController>();
        if (cc != null && cc.enabled) cc.enabled = false; // กัน CharacterController ดันตำแหน่งกลับ

        player.transform.SetPositionAndRotation(target.transform.position, target.transform.rotation);

        if (cc != null) cc.enabled = true;

        // เคลียร์ค่าเป้าหมายหลังใช้งาน
        nextSpawnId = null;
    }
}
