﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using System.Collections;
using System.Collections.Generic;

[System.Serializable]
public class QTEIconData
{
    public string iconName;
    public Image iconImage;
    public List<KeyCode> sequence;
    public bool isCollected = false;   // ต้องเก็บก่อนใช้งาน
    public UnityEvent onSelect;        // Event เมื่อกด P
    public UnityEvent onQTESuccess;   // Event หลัง QTE สำเร็จ
    public UnityEvent onQTEFail;      // Event หลัง QTE ไม่สำเร็จ
}

public class QTEIconMenu : MonoBehaviour
{
    [Header("UI Settings")]
    public GameObject menuPanel;
    public Color normalColor = Color.white;
    public Color highlightColor = Color.yellow;

    [Header("Icons & QTE System")]
    public List<QTEIconData> icons = new List<QTEIconData>();
    public QTESequence qteSystem;

    [Header("QTE Success Message")]
    public Text successMessageText;
    public float messageDuration = 3f;

    private int currentIndex = 0;
    private bool isOpen = false;

    void Start()
    {
        if (menuPanel) menuPanel.SetActive(false);
        if (successMessageText) successMessageText.gameObject.SetActive(false);
        HighlightIcon();
    }

    void Update()
    {
        // เปิด/ปิดเมนู (Q)
        if (Input.GetKeyDown(KeyCode.Q))
        {
            isOpen = !isOpen;
            if (menuPanel) menuPanel.SetActive(isOpen);
            HighlightIcon();
        }

        if (!isOpen) return;

        // เลื่อนเลือกไอคอน (ข้ามไอคอนที่ยังไม่เก็บ)
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            SelectPreviousCollectedIcon();
        }
        else if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            SelectNextCollectedIcon();
        }

        // กด P เพื่อใช้งานไอคอน
        if (Input.GetKeyDown(KeyCode.P))
        {
            if (currentIndex >= icons.Count) return;

            QTEIconData selectedIcon = icons[currentIndex];
            if (!selectedIcon.isCollected) return; // ต้องเก็บก่อนใช้งาน

            selectedIcon.onSelect?.Invoke();

            if (qteSystem != null && selectedIcon.sequence != null)
            {
                UnityEngine.Events.UnityAction onSuccess = () =>
                {
                    selectedIcon.onQTESuccess?.Invoke();
                    ShowSuccessMessage(selectedIcon.iconName);
                    selectedIcon.isCollected = false; // ต้องเก็บใหม่
                    HighlightIcon();
                };
                UnityEngine.Events.UnityAction onFail = () =>
                {
                    selectedIcon.onQTEFail?.Invoke();
                };

                qteSystem.StartQTEWithSequence(selectedIcon.sequence, onSuccess, onFail);
            }

            if (menuPanel) menuPanel.SetActive(false);
            isOpen = false;
        }
    }

    private void HighlightIcon()
    {
        for (int i = 0; i < icons.Count; i++)
        {
            if (icons[i].iconImage != null)
            {
                // แสดงเฉพาะไอคอนที่เก็บแล้ว
                bool show = icons[i].isCollected && i == currentIndex;
                icons[i].iconImage.gameObject.SetActive(show);
                icons[i].iconImage.color = (i == currentIndex) ? highlightColor : normalColor;
            }
        }
    }

    private void SelectNextCollectedIcon()
    {
        if (icons.Count == 0) return;
        int startIndex = currentIndex;
        do
        {
            currentIndex = (currentIndex + 1) % icons.Count;
            if (icons[currentIndex].isCollected) break;
        } while (currentIndex != startIndex);

        HighlightIcon();
    }

    private void SelectPreviousCollectedIcon()
    {
        if (icons.Count == 0) return;
        int startIndex = currentIndex;
        do
        {
            currentIndex = (currentIndex - 1 + icons.Count) % icons.Count;
            if (icons[currentIndex].isCollected) break;
        } while (currentIndex != startIndex);

        HighlightIcon();
    }

    private void ShowSuccessMessage(string iconName)
    {
        if (successMessageText == null) return;
        StopAllCoroutines();
        successMessageText.text = $"{iconName} สำเร็จ!";
        successMessageText.gameObject.SetActive(true);
        StartCoroutine(HideMessageAfterDelay());
    }

    private IEnumerator HideMessageAfterDelay()
    {
        yield return new WaitForSeconds(messageDuration);
        if (successMessageText) successMessageText.gameObject.SetActive(false);
    }

    // สำหรับ ItemTrigger ใช้เพื่อเก็บไอคอน
    public void CollectIcon(int index)
    {
        if (index < 0 || index >= icons.Count) return;
        icons[index].isCollected = true;
    }

    public int GetCurrentIndex()
    {
        return currentIndex;
    }

    public bool HasSelectedIcon()
    {
        return currentIndex >= 0 && currentIndex < icons.Count && icons[currentIndex].isCollected;
    }

}
