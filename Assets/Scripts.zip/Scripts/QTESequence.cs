using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using System.Collections.Generic;

public class QTESequence : MonoBehaviour
{
    public List<KeyCode> sequence = new List<KeyCode>();
    public float timeLimit = 5f;
    private float timer;
    private int currentIndex = 0;
    private bool isActive = false;

    public Text displayText;
    public Image timerBar;

    private UnityAction onSuccessEvent;
    private UnityAction onFailEvent;

    void Start()
    {
        if (displayText) displayText.gameObject.SetActive(false);
        if (timerBar) timerBar.gameObject.SetActive(false);
    }

    void Update()
    {
        if (!isActive) return;

        timer -= Time.deltaTime;
        if (timerBar) timerBar.fillAmount = timer / timeLimit;

        if (timer <= 0f)
        {
            Fail();
            return;
        }

        if (Input.anyKeyDown)
        {
            if (Input.GetKeyDown(sequence[currentIndex]))
            {
                currentIndex++;
                UpdateDisplay();

                if (currentIndex >= sequence.Count)
                {
                    Success();
                }
            }
            else
            {
                Fail();
            }
        }
    }

    public void StartQTEWithSequence(List<KeyCode> customSequence, UnityAction onSuccess, UnityAction onFail)
    {
        sequence = new List<KeyCode>(customSequence);
        onSuccessEvent = onSuccess;
        onFailEvent = onFail;
        StartQTE();
    }

    public void StartQTE()
    {
        isActive = true;
        timer = timeLimit;
        currentIndex = 0;
        UpdateDisplay();
        if (displayText) displayText.gameObject.SetActive(true);
        if (timerBar) timerBar.gameObject.SetActive(true);
    }

    private void UpdateDisplay()
    {
        if (displayText)
        {
            displayText.text = currentIndex < sequence.Count ? "Next: " + sequence[currentIndex] : "Done!";
        }
    }

    private void Success()
    {
        isActive = false;
        if (displayText) displayText.gameObject.SetActive(false);
        if (timerBar) timerBar.gameObject.SetActive(false);
        onSuccessEvent?.Invoke();
    }

    private void Fail()
    {
        isActive = false;
        if (displayText) displayText.gameObject.SetActive(false);
        if (timerBar) timerBar.gameObject.SetActive(false);
        onFailEvent?.Invoke();
    }
}
