using UnityEngine;
using UnityEngine.Events;

public class TriggerEvent : MonoBehaviour
{
    [Header("Player Settings")]
    public string playerTag = "Player";

    [Header("QTE ���͹䢡�÷ӧҹ")]
    public QTEIconMenu iconMenu;     // ��ҧ�ԧ价�� QTEIconMenu
    public int requiredIconIndex = 0; // Index �ͧ�ͤ͹����ͧ���͡

    [Header("Events")]
    public UnityEvent onCorrectIcon; // �ӧҹ������͡�ͤ͹�١
    public UnityEvent onWrongIcon;   // �ӧҹ������͡�Դ
    public UnityEvent onPlayerExit;

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag(playerTag)) return;

        if (iconMenu == null || !iconMenu.HasSelectedIcon()) return; // ��Ǩ�ͺ������͡�ͤ͹����

        int current = iconMenu.GetCurrentIndex();
        if (current == requiredIconIndex)
        {
            onCorrectIcon.Invoke();
        }
        else
        {
            onWrongIcon.Invoke();
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag(playerTag))
        {
            onPlayerExit.Invoke();
        }
    }
}
