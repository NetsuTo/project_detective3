using UnityEngine;
using UnityEngine.SceneManagement;

[RequireComponent(typeof(Collider))]
public class SceneSpawnTrigger : MonoBehaviour
{
    [Header("Load Target")]
    [Tooltip("���ͫչ����ͧ�����Ŵ (��ͧ�١���� Build Settings ����)")]
    public string sceneName;

    [Tooltip("SpawnId �ͧ�ش�Դ㹫չ����")]
    public string destinationSpawnId = "Default";

    [Header("Options")]
    public string requiredTag = "Player";
    public float delay = 0f;
    public bool onlyOnce = true;
    public bool loadAdditive = false;

    private bool triggered;

    private void Reset()
    {
        var col = GetComponent<Collider>();
        if (col) col.isTrigger = true;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (triggered) return;
        if (!string.IsNullOrEmpty(requiredTag) && !other.CompareTag(requiredTag)) return;
        if (string.IsNullOrWhiteSpace(sceneName))
        {
            Debug.LogWarning("[SceneSpawnTrigger] sceneName ��ҧ");
            return;
        }

        // �ѹ�֡���·ҧ���������� SpawnManager ����ѧ��Ŵ�չ
        SpawnManager.nextSpawnId = destinationSpawnId;

        StartCoroutine(LoadRoutine());

        if (onlyOnce) triggered = true;
    }

    private System.Collections.IEnumerator LoadRoutine()
    {
        if (delay > 0f) yield return new WaitForSeconds(delay);
        var mode = loadAdditive ? LoadSceneMode.Additive : LoadSceneMode.Single;
        SceneManager.LoadScene(sceneName, mode);
    }
}
